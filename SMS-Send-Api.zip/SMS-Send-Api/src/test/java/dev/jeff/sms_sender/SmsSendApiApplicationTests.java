package dev.jeff.sms_sender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsSendApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
