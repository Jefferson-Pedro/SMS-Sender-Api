package dev.jeff.sms_sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsSendApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsSendApiApplication.class, args);
	}

}
